const suits=[['♠',false],['♥',true],['♦',true],['♣',false]], ranks=['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
let deck=[],player=[],cpu=[],discard=[],phase='draw',selected=null;
const $=id=>document.getElementById(id);
function makeDeck(){return suits.flatMap(([s,red])=>ranks.map((r,i)=>({s,r,red,v:i+1,id:s+r})));}
function shuffle(a){for(let i=a.length-1;i;i--){let j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
function cardEl(c,clickable=false,index=-1){let b=document.createElement(clickable?'button':'div');b.className='card'+(c.red?' red':'')+(selected===index?' selected':'');b.innerHTML=`${c.r}<span class="suit">${c.s}</span>`;if(clickable)b.onclick=()=>chooseDiscard(index);return b}
function render(){ $('cpuCount').textContent=`(${cpu.length}枚)`;$('cpuHand').innerHTML='';cpu.forEach(()=>{let x=document.createElement('div');x.className='card backcard';$('cpuHand').appendChild(x)});$('playerHand').innerHTML='';player.forEach((c,i)=>$('playerHand').appendChild(cardEl(c,phase==='discard',i)));$('discardCard').innerHTML='';if(discard.length)$('discardCard').appendChild(cardEl(discard.at(-1)));$('stockCount').textContent=deck.length;$('phaseHint').textContent=phase==='draw'?'— 1枚引く':phase==='discard'?'— 捨てるカードを選ぶ':'— CPUの番';}
function status(t){$('status').textContent=t}
function newGame(){deck=shuffle(makeDeck());player=[];cpu=[];discard=[];for(let i=0;i<10;i++){player.push(deck.pop());cpu.push(deck.pop())}discard.push(deck.pop());phase='draw';selected=null;sortHand();status('山札か捨て札をタップして1枚引いてください');render()}
function sortHand(){player.sort((a,b)=>suits.findIndex(x=>x[0]===a.s)-suits.findIndex(x=>x[0]===b.s)||a.v-b.v)}
function draw(fromDiscard){if(phase!=='draw')return;if(fromDiscard){if(!discard.length)return;player.push(discard.pop())}else{if(deck.length<=2){status('山札が残り2枚になりました。このラウンドは終了です');phase='end';render();return}player.push(deck.pop())}phase='discard';selected=null;status('捨てるカードを1枚選んでください');render()}
function chooseDiscard(i){if(phase!=='discard')return;if(selected===i){discard.push(player.splice(i,1)[0]);selected=null;phase='cpu';status('CPUの番です…');render();setTimeout(cpuTurn,550)}else{selected=i;status(`${player[i].s}${player[i].r} をもう一度タップすると捨てます`);render()}}
function cpuTurn(){let takeDiscard=Math.random()<.28&&discard.length;if(takeDiscard)cpu.push(discard.pop());else if(deck.length>2)cpu.push(deck.pop());else{status('山札が残り2枚になりました。このラウンドは終了です');phase='end';render();return}let idx=Math.floor(Math.random()*cpu.length);discard.push(cpu.splice(idx,1)[0]);phase='draw';status('あなたの番です。1枚引いてください');render()}
$('stock').onclick=()=>draw(false);$('discard').onclick=()=>draw(true);$('newGame').onclick=newGame;newGame();
